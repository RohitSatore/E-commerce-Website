
<?php

  include "../vendor/register.html";

 echo "Hello Admin";
?>

