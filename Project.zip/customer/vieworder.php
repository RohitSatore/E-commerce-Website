<html>
<head>
	<style>
		.mycard
		{
			width: 200px;
			height: 160px;
			display: inline-block;
			padding: 10px;
			margin: 25px;
			margin-bottom: 80px;
		}

		img
		{
			width: 100%;
			height: 80%;
		}

		.place
		{
			display: flex;
			margin-top: 10px;
		}

		body
		{
			background-color: #ff9999;
		}

	</style>
</head>
<body>

</body>
</html>

<?php

  include "../shared/authguard.php";
  
  include "menu.html";

  $userid=$_SESSION['userid'];

  include_once "../shared/connection.php";

  $sql_result = mysqli_query($conn,"select * from cart join product on product.pid=cart.pid where userid=$userid and is_ordered=1");

  $total_price=0;
  $count=0;

  while($row=mysqli_fetch_assoc($sql_result))
   {
   	$cartid=$row['cartid'];
   	$pid = $row['pid'];
   	$name = $row['name'];
   	$price = $row['price'];
   	$detail = $row['detail'];
   	$impath = $row['impath'];

   	$total_price=$total_price+$row['price'];

   	echo  "<div class='mycard'>
               <div>Product no: $count</div>
               <div>Product Name: $name</div>
 
               <div>
                   Product desc:
                   $detail
                  <img src='$impath'>
               </div>
               <div class='mt-3'>
                 <a href='cancelorder.php?cartid=$cartid'> 
                   <button class='btn btn-primary'>Cancel order</button>
                 </a>
              </div>
	     </div>";
	     $count++;
   }

 ?>  