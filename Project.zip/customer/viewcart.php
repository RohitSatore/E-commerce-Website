<html>
<head>
	<style>
		.mycard
		{
			width: 200px;
			height: 160px;
			display: inline-block;
			padding: 10px;
			margin: 25px;
			margin-bottom: 80px;
		}

		img
		{
			width: 100%;
			height: 80%;
		}
		body
		{
			background-color: darkred;
		}
	</style>
</head>
<body>
<!-- <h1>Customer home work here</h1> -->
<!-- <div>$detail</div> -->
<!-- <div class='desc'>Product Description: $detail</div> -->

<!-- <script>
	function validate() {
		res=alert("Are sure want to placeorder");
		return res;
	}
	// for the pop
	<from method='get' action='placeorder.php' onsubmit='return validate()'>
          <input type='pid' style='display:none'>
          <button class='btn btn-danger'>Placeorder</button>
        </form>
</script> -->
</body>
</html>
<?php

  include "../shared/authguard.php";
  
  include "menu.html";

  $userid=$_SESSION['userid'];

  include_once "../shared/connection.php";

  $sql_result = mysqli_query($conn,"select * from cart join product on product.pid=cart.pid where userid=$userid and is_ordered=0");

  $total_price=0;
  $count=0;

  while($row=mysqli_fetch_assoc($sql_result))
   {
   	$cartid=$row['cartid'];
   	$pid = $row['pid'];
   	$name = $row['name'];
   	$price = $row['price'];
   	$detail = $row['detail'];
   	$impath = $row['impath'];

   	$total_price=$total_price+$row['price'];

   	echo  "<div class='mycard'>
               <div>Product no: $count</div>
               <div>Product Name: $name</div>
 
               <div>
                   Product picture:
                  <img src='$impath'>
               </div>
               
              <div class='mt-3'>
                 <a href='deletecart.php?cartid=$cartid'> 
                   <button class='btn btn-primary'>Remove to cart</button>
                 </a>
              </div>
	     </div>";
	     $count++;
   }

   if($total_price>0)
   {
   	echo "<div  class='place'>
       <div class='display-2'>Gross total: RS.$total_price</div>
       <div class='orderbtn'>
            <a href='placeorder.php'> 
                <button class='btn btn-danger'>Placeorder</button>
            </a>
        </div>

   </div>";
   }
   else
   {
   	echo "<di class='display-2'v>No items in cart.</div>";
   }
?>