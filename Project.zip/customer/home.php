<html>
<head>
	<style>
		.mycard
		{
			width: 200px;
			height: 160px;
			display: inline-block;
			padding: 10px;
			margin: 25px;
			margin-bottom: 80px;
		}

		img
		{
			width: 100%;
			height: 80%;
		}
	</style>
</head>
<body>
<!-- <h1>Customer home work here</h1> -->
<!-- <div>$detail</div> -->
<!-- <div class='desc'>Product Description: $detail</div> -->
</body>
</html>

<?php
   
   include "../shared/authguard.php";
   include "menu.html";

   include_once "../shared/connection.php";

   $userid = $_SESSION['userid'];

   $sql_result = mysqli_query($conn,"select * from product");

   $count=0;

   while($row=mysqli_fetch_assoc($sql_result))
   {
   	$pid = $row['pid'];
   	$name = $row['name'];
   	$price = $row['price'];
   	$detail = $row['detail'];
   	$impath = $row['impath'];


   	echo  "<div class='mycard'>
               <div>Product no: $count</div>
               <div>Product Name: $name</div>
 
               <div>
                   Product picture:
                  <img src='$impath'>
               </div>
               
              <div class='mt-3'>
                 <a href='addcart.php?pid=$pid'> 
                   <button>Add to cart</button>
                 </a>
              </div>
	     </div>";
   	 $count++;
   }
?>
