<?php
   
   $conn = new mysqli("localhost","root","","acme23",3308);

   if($conn->connect_error)
   {
   	echo "Connection failed";
   	die;
   }
   // else
   // {
   //    echo "Connection Success";
   // }

?>